			<div class="socials animated" data-animation="fadeInLeft" data-animation-delay="400">
				<!-- Facebook -->
				<a href="#" target="_blank" class="social">
					<i class="fa fa-facebook"></i>
				</a>
				<!-- Twitter -->
				<a href="#" target="_blank" class="social">
					<i class="fa fa-twitter"></i>
				</a>
				<!-- Instagram -->
				<a href="#" class="social">
					<i class="fa fa-instagram"></i>
				</a>
				<!-- Linkedin -->
				<a href="#" target="_blank" class="social">
					<i class="fa fa-linkedin"></i>
				</a>
				<!-- Vimeo -->
				<a href="#" target="_blank" class="social">
					<i class="fa fa-vimeo-square"></i>
				</a>
				<!-- Youtube -->
				<a href="#" target="_blank" class="social">
					<i class="fa fa-youtube"></i>
				</a>               
				<!-- Google Plus -->
				<a href="#" target="_blank" class="social">
					<i class="fa fa-google-plus"></i>
				</a>                
			</div>
			<!-- Adress, Mail -->
			<div class="address socials animated" data-animation="fadeInRight" data-animation-delay="500">
				<!-- Phone Number, Mail -->
				<p>Phone: +1 (800) 245-1234 Email : <a href="mailto:info@Fitness.com" class="colored">info@Fitness.com</a> Address: 23 Renesa, Surma Beach, Newyork</p>
				<!-- Top Button -->
				<a href="#home" class="scroll top-button">
					<i class="fa fa-arrow-circle-up fa-2x"></i>
				</a>
			</div><!-- End Adress, Mail -->
		</div><!-- End Inner -->
	</section><!-- End Site Socials and Address -->